// See LICENSE.txt for license details.
package problems

import chisel3._

// Problem:
//
// Implement test for this module. Please edit:
// .../chisel-tutorial/src/test/scala/problems/MaxNTests.scala
//
class MaxN(val n: Int, val w: Int) extends Module {

  private def Max2(x: UInt, y: UInt) = x max y // Mux(x > y, x, y)

  val io = IO(new Bundle {
    val ins = Input(Vec(n, UInt(w.W)))
    val out = Output(UInt(w.W))
  })

  /**
   * Return the maximum value in the range [begin, end) in data
   */
  def treeMax(data : Array[Int], begin : Int, end : Int) : Int =
    if (end == begin + 1) {
      data(begin)
    } else {
      val mid = (begin + end) / 2
      val r1 = treeMax(data, begin, mid)
      val r2 = treeMax(data, mid, end)
      r1 max r2
    }

  /**
   * Construct a circuit that will compute the maximum value in the
   * range [begin, end) in data
   */
  def treeMaxCirc(data : Vec[UInt], begin : Int, end : Int) : UInt =
    if (end == begin + 1) {
      data(begin)
    } else {
      val mid = (begin + end) / 2
      val r1 = treeMaxCirc(data, begin, mid)
      val r2 = treeMaxCirc(data, mid, end)
      r1 max r2
    }

  /**
   * Tree-shaped reduction, apply the function f to elements in the
   * range [begin, end) in data
   */
  def treeReduce[T <: Data]
                (data : Vec[T], begin : Int, end : Int)
                (f : (T, T) => T) : T =
    if (end == begin + 1) {
      data(begin)
    } else {
      val mid = (begin + end) / 2
      val r1 = treeReduce(data, begin, mid)(f)
      val r2 = treeReduce(data, mid, end)(f)
      f(r1, r2)
    }

  //  io.out := io.ins.reduceLeft(Max2)

  //  io.out := treeMaxCirc(io.ins, 0, n)

  io.out := treeReduce(io.ins, 0, n)(_ max _)
}
