// See LICENSE.txt for license details.
package problems

import chisel3.iotesters.PeekPokeTester

// Problem:
//
// Implement test for MaxN using PeekPokeTester
//
class MaxNTests(c: MaxN) extends PeekPokeTester(c) {
  for (i <- 0 until 10) {
    val contents = (for (_ <- 0 until c.n) yield rnd.nextInt(1 << c.w)).toList
    val mx = contents.max

    for (i <- 0 until c.n) {
      poke(c.io.ins(i), contents(i))
    }
    step(1)
    // Implement below ----------
    expect(c.io.out, mx)
    // Implement above ----------
  }
}
